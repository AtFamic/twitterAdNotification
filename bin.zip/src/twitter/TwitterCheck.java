package twitter;

public class TwitterCheck extends TwitterProcesses {

	@Override
	public boolean process() {
		return false;
	}

}
