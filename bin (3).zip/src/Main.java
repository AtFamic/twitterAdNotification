import periodic.PeriodicProcesses;

public class Main {

	public static void main(String[] args) {
		
		PeriodicProcesses pp = new PeriodicProcesses();
		pp.process();
		
//		TwitterProcesses tw = new TwitterProcesses(false);
//		tw.process();
		
	}

}
