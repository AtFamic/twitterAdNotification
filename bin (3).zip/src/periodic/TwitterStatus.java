package periodic;
/**
 * Twitter状況を定義するクラスです。
 * @author sakak
 *
 *
 */
public enum TwitterStatus {
	OnStatus, OffStatus,
}
