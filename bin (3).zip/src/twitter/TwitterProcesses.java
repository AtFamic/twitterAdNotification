package twitter;

import java.util.ArrayList;
import java.util.Iterator;

import org.sikuli.script.Screen;

import periodic.TwitterStatus;
import upper.Processes;

public class TwitterProcesses extends Processes {
	//private String twitterURL = "https://twitter.com/";
	boolean flag;
	//変更したいアカウント総数
	static final int account_num = 3;
	//変更したいアカウントの画像URL配列
	static final String[] account_pic = {"imgs/twitter/ChangeAccounts/CarrerInfo.PNG",
											"imgs/twitter/ChangeAccounts/OsakaCulturalClothesCollege.PNG",
											"imgs/twitter/ChangeAccounts/ToyotaMotorCollege.PNG"};


	private TwitterStatus status;

	Screen screen = new Screen();
	//処理手順(Process Chain)
	private ArrayList<TwitterProcesses> processChain = new ArrayList<TwitterProcesses>();


	//コンストラクタでonStatusかoffStatusを選択
	//さらに画像URL配列を初期化する。
	public TwitterProcesses(TwitterStatus status) {
		this.status = status;
		if(this.status == TwitterStatus.valueOf("OnStatus")) {
			this.flag = false;
		}else {
			this.flag = true;
		}

	}
	public TwitterProcesses() {	}


	public boolean process() {
		TwitterProcesses LiT = new LoginTwitter();
		TwitterProcesses LM = new TwitterMain(this.flag);
		TwitterProcesses LoT = new LogoutTwitter();
		TwitterProcesses[] CA = new ChangeAccounts[account_num];
		CA[0] = new ChangeAccounts(0);
		//ツイッターにログイン後1番目のアカウントにログインする
		this.processChain.add(LiT);
		this.processChain.add(CA[0]);
		for(int i = 0; i < account_num; i++) {
			System.out.println("始まり：" + i);
			this.processChain.add(LM);
			if(i != (account_num - 1)) {
				CA[i + 1] = new ChangeAccounts(i + 1);
				this.processChain.add(CA[i + 1]);
			}
			System.out.println("現在:" + i);
		}
		System.out.println("外");
		this.processChain.add(LoT);
		Iterator<TwitterProcesses> it = this.processChain.iterator();
		while(it.hasNext()) {
			it.next().process();
		}
		return true;
	}


	void waitClick(String imgAdress) {
		try {
			Thread.sleep(500);
			super.clickRepeat(this.screen, imgAdress,3);
		}catch(Exception e) {
			e.getStackTrace();
		}
	}
	void wait(int waitTime) {
		try {
			Thread.sleep(waitTime);
		}catch(Exception e) {
			e.getStackTrace();
		}


	}


}
