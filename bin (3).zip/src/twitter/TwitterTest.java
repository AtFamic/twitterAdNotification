package twitter;

public class TwitterTest {

	public static void main(String[] args) {
		ChangeAccounts CA = new ChangeAccounts(0);
		CA.process();
		CA = new ChangeAccounts(1);
		CA.process();
		CA = new ChangeAccounts(2);
		CA.process();

	}

}
