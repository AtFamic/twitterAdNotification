package twitter;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Region;

/**
 * アカウントを変更するクラスです。
 * コンストラクタで今が何回目の回転なのかを判断します。
 * TwitterMainが終了し次第、このクラスが呼び出され、
 * その後TwitterMainに処理を移行します。
 * @author sakak
 *
 */
public class ChangeAccounts extends TwitterProcesses {
	/**
	 * 変更したいアカウント先の番号
	 */
	int change_num;

	/**
	 * アカウント変更先の初期化
	 * @param change_num 変更したいアカウント先の番号
	 */
	public ChangeAccounts(int change_num) {
		this.change_num = change_num;
	}


	@Override
	public boolean process() {
		wait(5000);
		//その場でクリックしてフォーカスを得る
		this.screen.click();
		try {
			new Region(1460,110,210,60).click();
			wait(3000);

			this.screen.click("imgs/twitter/ChangeAccounts/change_account.PNG");
			wait(5000);

			this.screen.click(this.account_pic[this.change_num]);
			wait(5000);
		}catch(FindFailed e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
